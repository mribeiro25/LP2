﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pfilme01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] avaliaFilme = new double[3, 2];
            double mediaFilme1 = 0, mediaFilme2 = 0;
            string auxiliar = " ";

            lstbxExibir.Items.Clear();

            for (int pessoa = 0; pessoa < 3; pessoa++)
            {
                for (int notaFilme = 0; notaFilme < 2; notaFilme++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota do filme {notaFilme + 1}", $"Avaliação da pessoa {pessoa + 1}");

                    if (!Double.TryParse(auxiliar, out avaliaFilme[pessoa, notaFilme]))
                    {
                        MessageBox.Show("Nota inválida!");
                        notaFilme--;
                    }
                    else if (avaliaFilme[pessoa, notaFilme] < 0 || avaliaFilme[pessoa, notaFilme] > 10)
                    {
                        MessageBox.Show("Nota deve estar entre 0 e 10");
                        notaFilme--;
                    }
                }
                mediaFilme1 += avaliaFilme[pessoa, 0];
                mediaFilme2 += avaliaFilme[pessoa, 1];
            }

            mediaFilme1 = avaliaFilme[0, 0] + avaliaFilme[1, 0] + avaliaFilme[2, 0];

            for (int pessoa = 0; pessoa < 3; pessoa++)
            {
                lstbxExibir.Items.Add
                ($"Pessoa {pessoa + 1}   Nota Filme 1: {avaliaFilme[pessoa, 0].ToString("N2")}     Nota Filme 2: {avaliaFilme[pessoa, 1].ToString("N2")}");
            }

            mediaFilme1 = mediaFilme1 / 3;
            mediaFilme2 = mediaFilme2 / 3;

            lstbxExibir.Items.Add("------------------------------------");
            lstbxExibir.Items.Add("Média filme 1: " + mediaFilme1.ToString("N2"));
            lstbxExibir.Items.Add("Média filme 2: " + mediaFilme2.ToString("N2"));
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxExibir.Items.Clear();
        }
    }
}
