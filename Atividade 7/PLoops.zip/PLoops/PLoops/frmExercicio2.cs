﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio2 : Form
    {
        int numN;
        double numH;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnGeraH_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(txtNum.Text, out numN))
            {
                MessageBox.Show("Número 1 inválido");
                txtNum.Focus();
            }
            else if (numN == 0)
            {
                MessageBox.Show("Número 1 deve ser maior que 0");
                txtNum.Focus();
            }
            else
            {
                for(double i = 1; i <= numN; i++)
                {
                    numH = numH + 1 / i;
                }

                txtH.Text = numH.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtH.Clear();
            txtNum.Clear();
        }
    }
}
