﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio4 : Form
    {
        double gratificacao, producao, salario, salBruto, B, C, D;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtGratificacao.Clear();
            txtProducao.Clear();
            txtSalBruto.Clear();
            txtMatricula.Clear();
            txtSalBruto.Clear();
            txtNome.Clear();
        }

        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtProducao.Text, out producao))
            {
                MessageBox.Show("Númmero de produção inválido");
                txtProducao.Clear();
                txtProducao.Focus();
            }
            else if (!Double.TryParse(txtSalario.Text, out salario))
            {
                MessageBox.Show("Salário inválido");
                txtSalario.Clear();
                txtSalario.Focus();
            }
            else if (!Double.TryParse(txtGratificacao.Text, out gratificacao))
            {
                MessageBox.Show("Gratificação inválida");
            }
            else
            {
                B = (producao >= 100) ? 1 : 0;
                C = (producao >= 120) ? 1 : 0;
                D = (producao >= 150) ? 1 : 0;

                salBruto = salario + (salario * (0.05 * B + 0.1 * C + 0.1 * D)) + gratificacao;

                if (salBruto > 7000)
                {
                    
                    if (producao < 150 || gratificacao <= 0)
                    {
                        salBruto = 7000;
                    }
                }

                txtSalBruto.Text = "R$ " + salBruto;
            }
        }
    }
}
