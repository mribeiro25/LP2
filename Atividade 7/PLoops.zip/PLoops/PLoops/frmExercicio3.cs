﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerifca_Click(object sender, EventArgs e)
        {
            string palavra1 = txtFrase.Text.Replace(" ","").ToUpper();

            char[] palavraInvertida = palavra1.ToCharArray();

            Array.Reverse(palavraInvertida);

            string palavra2 = new string(palavraInvertida);

            if (palavra1 == palavra2)
            {
                MessageBox.Show("A frase é um palíndrono");
            }
            else
            {
                MessageBox.Show("A frase não é um palíndrono");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtFrase.Clear();
        }
    }
}
