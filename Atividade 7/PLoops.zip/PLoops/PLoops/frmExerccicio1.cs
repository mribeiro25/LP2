﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class frmExerccicio1 : Form
    {
        int qntdR, qntdBranco, qntdIgual;
        public frmExerccicio1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string texto = rchtxtFrase.Text;

            foreach( char r in texto)
            {
                if( r == 'r' || r == 'R')
                {
                    qntdR++;
                }
            }


            MessageBox.Show("O texto possui " +  qntdR + " letras R");
            qntdR = 0;
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            rchtxtFrase.Clear();

        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            int i=0;

            while( i < frase.Length-1)
            {
                if ( frase[i] == frase[i+1])
                {
                    qntdIgual++;
                }
                i++;
            }
            MessageBox.Show("O texto possui " + qntdIgual + " pares de letras");
            qntdIgual = 0;
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            string frase = rchtxtFrase.Text;
            
            for( int i = 0;i < frase.Length; i++)
            {
                if( frase[i] == ' ')
                {
                    qntdBranco++;
                }
            }
            MessageBox.Show("O texto possui " + qntdBranco + " espaços em Branco");
            qntdBranco = 0;
        }
    }
}
