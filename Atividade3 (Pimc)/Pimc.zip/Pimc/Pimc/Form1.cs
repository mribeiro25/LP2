﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
            txtImc.Clear();
            mskbxPeso.Focus();
        }

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso inválido");
                e.Cancel = true;
            }else if (peso <= 0)
            {
                MessageBox.Show("Peso inválido (não pode ser 0)");
                e.Cancel = true;
            }
        }

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                e.Cancel = true;
            }else if (altura <= 0)
            {
                MessageBox.Show("Altura não pode ser 0");
                e.Cancel = true;
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(mskbxPeso.Text, out peso) ||
               !Double.TryParse(mskbxAltura.Text, out altura))
            {
                mskbxPeso.Focus();
            }
            else
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc,1);
                    
                txtImc.Text = imc.ToString();

                if(imc < 18.5){
                    MessageBox.Show("Magreza");
                } else if(imc >= 18.5 && imc < 24.9)
                {
                    MessageBox.Show("Normal");
                } else if(imc >= 24.9 && imc < 29.9)
                {
                    MessageBox.Show("Sobrepeso");
                } else if (imc >= 30 && imc < 39.9)
                {
                    MessageBox.Show("Obesidade");
                } else
                {
                    MessageBox.Show("Obsidade grave");
                }

            }
        }
    }
}
