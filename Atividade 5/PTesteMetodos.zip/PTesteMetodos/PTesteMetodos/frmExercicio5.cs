﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio5 : Form
    {
        int num1, num2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            listResultado.Clear();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if(!int.TryParse(txtNumero1.Text, out num1))
            {
                MessageBox.Show("Número 1 inválido");
                txtNumero1.Focus();
            }
            else if (!int.TryParse(txtNumero2.Text, out num2))
            {
                MessageBox.Show("Número 2 inválido");
                txtNumero2.Focus();
            }
            else if (num1 > num2)
            {
                MessageBox.Show("Número 2 deve ser maior que número 1");
                txtNumero1.Focus();
            }
            else
            {
                Random randNum = new Random();

                listResultado.Items.Add(randNum.Next(num1, num2).ToString());
            }
        }
    }
}
