﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rixhTxt1 = new System.Windows.Forms.RichTextBox();
            this.btnCaracterBranco = new System.Windows.Forms.Button();
            this.btnContaNum = new System.Windows.Forms.Button();
            this.btnAlfabeticos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rixhTxt1
            // 
            this.rixhTxt1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rixhTxt1.Location = new System.Drawing.Point(210, 37);
            this.rixhTxt1.Name = "rixhTxt1";
            this.rixhTxt1.Size = new System.Drawing.Size(364, 139);
            this.rixhTxt1.TabIndex = 0;
            this.rixhTxt1.Text = "";
            // 
            // btnCaracterBranco
            // 
            this.btnCaracterBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCaracterBranco.Location = new System.Drawing.Point(326, 212);
            this.btnCaracterBranco.Name = "btnCaracterBranco";
            this.btnCaracterBranco.Size = new System.Drawing.Size(124, 79);
            this.btnCaracterBranco.TabIndex = 9;
            this.btnCaracterBranco.Text = "Localizar caracter branco";
            this.btnCaracterBranco.UseVisualStyleBackColor = true;
            this.btnCaracterBranco.Click += new System.EventHandler(this.btnCaracterBranco_Click);
            // 
            // btnContaNum
            // 
            this.btnContaNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContaNum.Location = new System.Drawing.Point(181, 212);
            this.btnContaNum.Name = "btnContaNum";
            this.btnContaNum.Size = new System.Drawing.Size(124, 79);
            this.btnContaNum.TabIndex = 8;
            this.btnContaNum.Text = "Quant. Caracter numérico";
            this.btnContaNum.UseVisualStyleBackColor = true;
            this.btnContaNum.Click += new System.EventHandler(this.btnContaNum_Click);
            // 
            // btnAlfabeticos
            // 
            this.btnAlfabeticos.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlfabeticos.Location = new System.Drawing.Point(470, 212);
            this.btnAlfabeticos.Name = "btnAlfabeticos";
            this.btnAlfabeticos.Size = new System.Drawing.Size(124, 79);
            this.btnAlfabeticos.TabIndex = 10;
            this.btnAlfabeticos.Text = "Qntd Caracter alfabético";
            this.btnAlfabeticos.UseVisualStyleBackColor = true;
            this.btnAlfabeticos.Click += new System.EventHandler(this.btnAlfabeticos_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAlfabeticos);
            this.Controls.Add(this.btnCaracterBranco);
            this.Controls.Add(this.btnContaNum);
            this.Controls.Add(this.rixhTxt1);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rixhTxt1;
        private System.Windows.Forms.Button btnCaracterBranco;
        private System.Windows.Forms.Button btnContaNum;
        private System.Windows.Forms.Button btnAlfabeticos;
    }
}