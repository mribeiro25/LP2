﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContaNum_Click(object sender, EventArgs e)
        {
            int tamanho = rixhTxt1.Text.Length, contador = 0, i = 0;
            string txt = rixhTxt1.Text;

            while (i < tamanho) 
            { 
                if(char.IsDigit(txt[i]))
                {
                    contador++;
                }
                i++;
            }
            MessageBox.Show("O texto tem " + contador + " caracteres numéricos");
        }

        private void btnCaracterBranco_Click(object sender, EventArgs e)
        {
            int i = 0, posicao = 0;
            string txt = rixhTxt1.Text;

            for (i=0; i < txt.Length;i++)
            {
                if(char.IsWhiteSpace(txt[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }

            if(posicao == 0)
            {
                MessageBox.Show("NÃO HÁ ESPAÇO EM BRANCO");
            }
            else
            {
                MessageBox.Show("ESPAÇO EM BRANCO NA POSIÇÃO " + posicao);
            }
        }

        private void btnAlfabeticos_Click(object sender, EventArgs e)
        {
            int cont = 0;
            string txt = rixhTxt1.Text;

            foreach(char c in txt)
            {
                if (char.IsLetter(c))
                {
                    cont++;
                }
            }

            MessageBox.Show("O texto possui " + cont + " caracteres alfabéticos");
            
        }
    }
}
