﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        string resultado;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
            txtResultado.Clear();

            txtLadoA.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Deseja sair?","Saída",MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Lado A inválido");
                txtLadoA.Focus();
                
            }
            else if (ladoA <= 0)
            {
                MessageBox.Show("Lado A não pode ser 0");
                txtLadoA.Focus();
            }
            else if (!Double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Lado B inválido");
                txtLadoB.Focus();
            }
            else if (ladoB <= 0)
            {
                MessageBox.Show("Lado B não pode ser 0");
                txtLadoB.Focus();
            }
            else if (!Double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Lado C inválido");
                txtLadoC.Focus();
            }
            else if (ladoC <= 0)
            {
                MessageBox.Show("Lado C não pode ser 0");
                txtLadoC.Focus();
            }
            else if((Math.Abs(ladoB-ladoC) < ladoA && ladoA < (ladoB + ladoC)) &&
                    (Math.Abs(ladoA-ladoC) < ladoB && ladoB < (ladoA + ladoC)) &&
                    (Math.Abs(ladoA-ladoB) < ladoC && ladoC < (ladoA + ladoB)))
            {
                if(ladoA == ladoB && ladoB == ladoC)
                {
                    txtResultado.Text = "Equilátero";
                }
                else if (ladoA == ladoB || ladoB == ladoC || ladoA == ladoC)
                {
                    txtResultado.Text = "Isósceles";
                }
                else
                {
                    txtResultado.Text = "Escaleno";
                }
            } else
            {
                txtResultado.Text = "NÂO GEROU TRIÂNGULO";
            }
        }
    }
}
